
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { store } from '../services/store';
import { User, Invoice, Shipment, SupportRequest } from '../types';
import { ICONS } from '../constants';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const user = store.getCurrentUser();
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [requests, setRequests] = useState<SupportRequest[]>([]);
  const [activeTab, setActiveTab] = useState<'Shipments' | 'Invoices' | 'Requests'>('Shipments');

  useEffect(() => {
    if (user) {
      setInvoices(store.getInvoicesByClient(user.id));
      setShipments(store.getShipments().filter(s => s.clientId === user.id));
      setRequests(store.getRequestsByClient(user.id));
    }
  }, [user]);

  if (!user || user.role !== 'CLIENT') {
    return (
      <div className="pt-40 text-center flex flex-col items-center">
        <p className="text-gray-400 font-medium italic mb-4">Please log in to your client portal.</p>
        <button onClick={() => navigate('/auth')} className="text-xs font-bold uppercase tracking-widest bg-gray-900 text-white px-8 py-3 rounded-full">Login</button>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-40 px-6 max-w-7xl mx-auto min-h-screen">
      <header className="mb-20 flex flex-col md:flex-row justify-between items-start md:items-end gap-10">
        <div>
          <h1 className="text-4xl font-bold tracking-tight mb-2">Command Overview</h1>
          <p className="text-gray-400 text-sm font-medium">Enterprise portal for {user.companyName}</p>
        </div>
        <button 
          onClick={() => navigate('/request')}
          className="px-10 py-5 bg-gray-900 text-white rounded-full text-xs font-bold uppercase tracking-widest hover:bg-black transition-colors"
        >
          Initiate New Service
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
        {/* Nav */}
        <div className="lg:col-span-1 space-y-1">
            <TabBtn active={activeTab === 'Shipments'} onClick={() => setActiveTab('Shipments')} label="Shipments" count={shipments.length} />
            <TabBtn active={activeTab === 'Invoices'} onClick={() => setActiveTab('Invoices')} label="Invoices" count={invoices.length} />
            <TabBtn active={activeTab === 'Requests'} onClick={() => setActiveTab('Requests')} label="Requests" count={requests.length} />
        </div>

        {/* Workspace */}
        <div className="lg:col-span-3">
          {activeTab === 'Shipments' && (
            <div className="space-y-6">
              {shipments.length === 0 ? (
                <EmptyState message="Shipment details will appear once processing begins." />
              ) : (
                shipments.map(s => (
                  <div key={s.id} className="bg-white p-12 rounded-[48px] border border-gray-100">
                    <div className="flex justify-between items-start mb-10">
                      <div>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">TRACKING: {s.trackingNumber}</p>
                        <h3 className="text-2xl font-bold text-gray-900">{s.status}</h3>
                      </div>
                      <span className="px-4 py-1.5 bg-gray-50 text-gray-900 rounded-full text-[10px] font-bold uppercase tracking-widest border border-gray-100">Current</span>
                    </div>
                    <div className="w-full bg-gray-100 h-1 rounded-full overflow-hidden mb-8">
                      <div className="bg-gray-900 h-full transition-all duration-1000" style={{ width: `${s.progress}%` }}></div>
                    </div>
                    <p className="text-sm text-gray-500 italic leading-relaxed">"{s.clientNotes}"</p>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'Invoices' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {invoices.length === 0 ? (
                <EmptyState message="No invoices issued to your account yet." />
              ) : (
                invoices.map(inv => (
                  <div key={inv.id} className="bg-white p-12 rounded-[48px] border border-gray-100 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-10">
                        <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-gray-400">{inv.id}</h3>
                        <span className={`px-4 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest border ${inv.status === 'Paid' ? 'border-green-100 text-green-600 bg-green-50' : 'border-gray-100 text-gray-400 bg-gray-50'}`}>
                          {inv.status}
                        </span>
                      </div>
                      <div className="mb-12">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Invoice Amount</p>
                        <p className="text-4xl font-bold text-gray-900">${inv.totalAmount.toLocaleString()}</p>
                        
                        {inv.showBreakdown && (
                          <div className="mt-8 pt-8 border-t border-gray-50 space-y-4 text-xs font-medium text-gray-400">
                             <div className="flex justify-between"><span>Manufacturing</span><span className="text-gray-900">${inv.productCost.toLocaleString()}</span></div>
                             <div className="flex justify-between"><span>Logistics</span><span className="text-gray-900">${inv.shippingCost.toLocaleString()}</span></div>
                             <div className="flex justify-between"><span>Quality Control</span><span className="text-gray-900">${inv.inspectionCost.toLocaleString()}</span></div>
                          </div>
                        )}
                      </div>
                    </div>
                    <button className="w-full py-4 bg-gray-900 text-white rounded-3xl text-[10px] font-bold uppercase tracking-widest hover:bg-black transition-colors">Download PDF Statement</button>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'Requests' && (
            <div className="space-y-4">
              {requests.length === 0 ? (
                <EmptyState message="No requests submitted." />
              ) : (
                requests.map(req => (
                  <div key={req.id} className="bg-white p-10 rounded-[40px] border border-gray-100 flex flex-col md:flex-row justify-between items-center gap-10">
                    <div className="flex-1">
                      <div className="flex items-center gap-6 mb-3">
                        <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400">{req.type}</span>
                        <span className={`px-2 py-0.5 rounded-[4px] text-[8px] font-bold uppercase border ${req.status === 'Completed' ? 'border-green-100 text-green-600' : 'border-blue-100 text-blue-600'}`}>
                          {req.status}
                        </span>
                      </div>
                      <p className="text-lg font-bold text-gray-900 mb-2 truncate max-w-md">{req.details.split('\n')[0]}</p>
                      <p className="text-[9px] text-gray-400 font-bold uppercase tracking-[0.2em]">{new Date(req.createdAt).toLocaleDateString()}</p>
                    </div>
                    <button className="text-[10px] font-bold text-gray-900 uppercase tracking-widest border-b border-gray-900 pb-1">Review Request</button>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const TabBtn: React.FC<{ active: boolean, onClick: () => void, label: string, count: number }> = ({ active, onClick, label, count }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-between px-8 py-5 rounded-[24px] transition-all duration-300 ${active ? 'bg-gray-900 text-white' : 'text-gray-400 hover:bg-white hover:shadow-sm'}`}
  >
    <span className="text-xs font-bold uppercase tracking-widest">{label}</span>
    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${active ? 'bg-gray-800' : 'bg-gray-50 text-gray-400'}`}>{count}</span>
  </button>
);

const EmptyState: React.FC<{ message: string }> = ({ message }) => (
  <div className="py-32 text-center bg-white rounded-[64px] border border-gray-50 flex flex-col items-center">
    <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center mb-6 text-gray-200">
       <ICONS.Box className="w-6 h-6" />
    </div>
    <p className="text-gray-300 font-bold uppercase tracking-widest text-[10px]">{message}</p>
  </div>
);

export default Dashboard;
