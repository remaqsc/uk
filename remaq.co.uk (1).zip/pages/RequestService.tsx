
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { store } from '../services/store';
import { User, SupportRequest, RequestType } from '../types';
import { ICONS, COLORS } from '../constants';

const RequestService: React.FC = () => {
  const navigate = useNavigate();
  const user = store.getCurrentUser();
  const [step, setStep] = useState<'Select' | 'Form' | 'Success'>('Select');
  const [selectedType, setSelectedType] = useState<RequestType | null>(null);
  const [isLoadingForm, setIsLoadingForm] = useState(false);

  const handleSelect = (type: RequestType) => {
    setIsLoadingForm(true);
    setSelectedType(type);
    setTimeout(() => {
      setIsLoadingForm(false);
      setStep('Form');
      window.scrollTo(0, 0);
    }, 900);
  };

  const handleComplete = () => {
    setStep('Success');
    window.scrollTo(0, 0);
  };

  return (
    <div className="pt-32 pb-40 px-6 max-w-7xl mx-auto flex flex-col items-center min-h-screen relative page-enter">
      <div className="bg-blob top-[10%] left-[-10%] opacity-15"></div>
      <div className="bg-blob bottom-[10%] right-[-10%] opacity-10" style={{ background: 'radial-gradient(circle, rgba(99, 102, 241, 0.2) 0%, transparent 70%)' }}></div>

      {isLoadingForm && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center glass backdrop-blur-2xl animate-scale-in">
          <div className="w-24 h-24 border-t-2 border-b-2 border-blue-600 rounded-full animate-spin mb-10 shadow-[0_0_30px_rgba(59,130,246,0.3)]"></div>
          <p className="text-[11px] font-black uppercase tracking-[0.5em] text-blue-600 animate-pulse">Initializing Interface</p>
        </div>
      )}

      {step === 'Select' && (
        <div className="w-full text-center max-w-5xl">
          <header className="mb-28 animate-slide-up">
            <span className="inline-block px-4 py-1.5 mb-8 text-[10px] font-black uppercase tracking-[0.3em] text-blue-600 bg-blue-50/50 border border-blue-100 rounded-full">
              Mission Control
            </span>
            <h1 className="text-5xl md:text-7xl font-black tracking-tight mb-8">What are we building?</h1>
            <p className="text-gray-500 text-xl max-w-2xl mx-auto font-medium leading-relaxed">
              Select a core logistics protocol to begin your project initialization. We'll handle the complexity.
            </p>
          </header>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <ServiceOption 
              title="Sourcing" 
              icon={<ICONS.Search className="w-10 h-10" />}
              description="Find, audit, and negotiate with world-class manufacturers."
              delay="stagger-1"
              onClick={() => handleSelect('Sourcing')} 
            />
            <ServiceOption 
              title="Shipping" 
              icon={<ICONS.Ship className="w-10 h-10" />}
              description="Optimize global transit and handle customs automatically."
              delay="stagger-2"
              onClick={() => handleSelect('Shipping')} 
            />
            <ServiceOption 
              title="Inspection" 
              icon={<ICONS.Check className="w-10 h-10" />}
              description="Ensure every unit meets your exact specifications on-site."
              delay="stagger-3"
              onClick={() => handleSelect('Inspection')} 
            />
          </div>
        </div>
      )}

      {step === 'Form' && selectedType && (
        <div className="w-full max-w-4xl animate-slide-up">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-20 gap-8">
            <div className="group cursor-pointer" onClick={() => setStep('Select')}>
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-500 mb-3 block group-hover:text-blue-600 transition-colors">← Back to selection</span>
              <h1 className="text-4xl md:text-5xl font-black tracking-tighter">{selectedType} Specification</h1>
            </div>
          </div>
          
          <div className="bg-white p-12 md:p-20 rounded-[64px] border border-gray-100 shadow-[0_20px_50px_-20px_rgba(0,0,0,0.05)] hover:shadow-[0_40px_80px_-20px_rgba(59,130,246,0.1)] transition-all duration-700">
            <RequestForm 
              user={user} 
              type={selectedType} 
              onComplete={handleComplete} 
            />
          </div>
        </div>
      )}

      {step === 'Success' && (
        <div className="text-center py-24 animate-scale-in">
          <div className="w-28 h-28 bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-full flex items-center justify-center mx-auto mb-14 shadow-[0_30px_60px_rgba(59,130,246,0.3)] animate-float">
             <ICONS.Check className="w-12 h-12" />
          </div>
          <h2 className="text-6xl font-black mb-8 tracking-tighter">Signal Received.</h2>
          <p className="text-gray-500 mb-20 text-xl max-w-lg mx-auto leading-relaxed font-medium">
            Your {selectedType.toLowerCase()} request has been uploaded to the Remaq Command center. Our operational team will initiate contact shortly.
          </p>
          <div className="flex flex-col sm:flex-row gap-8 justify-center items-center">
            <button 
                onClick={() => navigate(user ? '/dashboard' : '/')} 
                className="w-full sm:w-auto px-16 py-6 bg-gray-900 text-white rounded-full font-black uppercase tracking-[0.2em] text-[11px] hover:bg-blue-600 transition-all shadow-2xl hover:shadow-blue-500/30 active:scale-95"
            >
                {user ? 'Command Dashboard' : 'Return to Base'}
            </button>
            <button 
                onClick={() => setStep('Select')} 
                className="w-full sm:w-auto px-12 py-6 glass border border-gray-200 text-gray-900 rounded-full font-black uppercase tracking-[0.2em] text-[11px] hover:border-gray-900 transition-all active:scale-95"
            >
                Initialize New Project
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const ServiceOption: React.FC<{ title: string, icon: React.ReactNode, description: string, delay: string, onClick: () => void }> = ({ title, icon, description, delay, onClick }) => (
  <button 
    onClick={onClick} 
    className={`p-14 bg-white border border-gray-100 rounded-[64px] hover-card group flex flex-col items-center text-center animate-slide-up ${delay}`}
  >
    <div className="w-24 h-24 bg-gray-50 text-gray-900 rounded-[32px] flex items-center justify-center mb-12 transition-all duration-700 group-hover:bg-blue-600 group-hover:text-white group-hover:shadow-[0_20px_40px_rgba(59,130,246,0.25)] group-hover:rotate-6">
       {icon}
    </div>
    <span className="font-black text-3xl mb-5 tracking-tighter group-hover:text-blue-600 transition-colors">{title}</span>
    <p className="text-sm text-gray-400 font-semibold leading-relaxed mb-12 max-w-[200px]">{description}</p>
    <div className="mt-auto px-10 py-4 bg-gray-50 rounded-full text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 group-hover:bg-gray-900 group-hover:text-white transition-all">
      Start Protocol
    </div>
  </button>
);

const RequestForm: React.FC<{ user: User | null, type: RequestType, onComplete: () => void }> = ({ user, type, onComplete }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<any>({
    clientName: user?.companyName || '',
    email: user?.email || '',
    productName: '',
    link: '',
    quantityPrice: '',
    shippingMethod: 'Regular Sea',
    numCartons: '',
    weight: '',
    pickup: '',
    delivery: '',
    factoryAddress: '',
    specialInstructions: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 2500));

    let details = '';
    if (type === 'Sourcing') details = `Sourcing: ${formData.productName}\nQty/Price: ${formData.quantityPrice}\nLink: ${formData.link}`;
    if (type === 'Shipping') details = `Shipping (${formData.shippingMethod}): ${formData.numCartons} cartons\nFrom: ${formData.pickup}\nTo: ${formData.delivery}`;
    if (type === 'Inspection') details = `Inspection: ${formData.productName}\nFactory: ${formData.factoryAddress}`;

    const newRequest: SupportRequest = {
      id: `REQ-${Date.now()}`,
      clientId: user?.id,
      companyName: formData.clientName,
      email: formData.email,
      type: type,
      details: details,
      formData: formData,
      status: 'Pending Review',
      createdAt: new Date().toISOString()
    };

    store.addRequest(newRequest);
    setIsSubmitting(false);
    onComplete();
  };

  return (
    <form onSubmit={handleSubmit} className={`space-y-20 transition-all duration-700 ${isSubmitting ? 'opacity-40 grayscale pointer-events-none' : 'opacity-100'}`}>
      {/* Identity Group */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 group">
         <FormInput label="Authority Context (Company Name)" value={formData.clientName} onChange={v => setFormData({...formData, clientName: v})} required placeholder="e.g. Acme Logistics Global" />
         <FormInput label="Direct Communication (Email)" type="email" value={formData.email} onChange={v => setFormData({...formData, email: v})} required placeholder="contact@company.com" />
      </div>

      <div className="pt-16 border-t border-gray-100">
        {type === 'Sourcing' && (
          <div className="space-y-12 animate-slide-up">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <FormInput label="Target Asset (Product Name)" value={formData.productName} onChange={v => setFormData({...formData, productName: v})} required placeholder="e.g. Ergonomic Office Chairs" />
              <FormInput label="Volume Requirement / Target Budget" value={formData.quantityPrice} onChange={v => setFormData({...formData, quantityPrice: v})} required placeholder="e.g. 500 units / $20k" />
            </div>
            <FormInput label="Reference Specifications (URL)" value={formData.link} placeholder="Paste link from Alibaba, Global Sources, etc." onChange={v => setFormData({...formData, link: v})} />
            <div className="p-8 bg-blue-50/50 rounded-[32px] border border-blue-100/50">
               <p className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-600 mb-2">Sourcing Protocol</p>
               <p className="text-xs text-blue-900/60 font-medium">Our specialists will audit the provided link and find 3-5 verified alternatives with better pricing and manufacturing scores.</p>
            </div>
          </div>
        )}

        {type === 'Shipping' && (
          <div className="space-y-16 animate-slide-up">
            <div className="space-y-8">
              <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 block ml-2">Transit Speed Configuration</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                {[
                  { id: 'Regular Sea', label: 'Sea Economy', time: '35-50 Days' },
                  { id: 'Fast Sea', label: 'Priority Sea', time: '18-26 Days' },
                  { id: 'Air', label: 'Air Express', time: '4-8 Days' }
                ].map(m => (
                  <label key={m.id} className={`flex flex-col items-center justify-center p-8 border-2 rounded-[40px] cursor-pointer transition-all duration-500 ${formData.shippingMethod === m.id ? 'bg-gray-900 border-gray-900 text-white shadow-2xl shadow-blue-500/10 scale-[1.02]' : 'bg-white border-gray-100 text-gray-400 hover:border-blue-200 hover:bg-blue-50/20'}`}>
                    <input type="radio" className="hidden" name="method" checked={formData.shippingMethod === m.id} onChange={() => setFormData({...formData, shippingMethod: m.id})} />
                    <span className="text-xs font-black uppercase tracking-[0.2em] mb-2">{m.label}</span>
                    <span className={`text-[9px] font-bold ${formData.shippingMethod === m.id ? 'text-blue-400' : 'text-gray-400'}`}>{m.time}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <FormInput label="Payload Volume (Total Cartons)" type="number" value={formData.numCartons} onChange={v => setFormData({...formData, numCartons: v})} required placeholder="e.g. 45" />
                <FormInput label="Gross Weight (Total kg)" value={formData.weight} onChange={v => setFormData({...formData, weight: v})} required placeholder="e.g. 980" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <FormInput label="Departure Node (Origin)" placeholder="City or Specific Factory" value={formData.pickup} onChange={v => setFormData({...formData, pickup: v})} required />
              <FormInput label="Arrival Node (Destination)" placeholder="Final Port or Warehouse" value={formData.delivery} onChange={v => setFormData({...formData, delivery: v})} required />
            </div>
          </div>
        )}

        {type === 'Inspection' && (
          <div className="space-y-12 animate-slide-up">
            <FormInput label="Quality Target (Product Name)" value={formData.productName} onChange={v => setFormData({...formData, productName: v})} required placeholder="e.g. Smart Watch Series 7" />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
               <div className="space-y-5">
                 <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 block ml-2">Target Coordinates (Address)</label>
                 <textarea 
                   required 
                   placeholder="Full manufacturing facility address..."
                   className="w-full bg-gray-50 border border-gray-100 rounded-[40px] py-8 px-10 focus:bg-white focus:border-blue-500 outline-none text-xs font-semibold h-48 transition-all shadow-inner resize-none leading-relaxed"
                   value={formData.factoryAddress}
                   onChange={e => setFormData({...formData, factoryAddress: e.target.value})}
                 />
               </div>
               <div className="space-y-5">
                 <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 block ml-2">Critical Parameters</label>
                 <textarea 
                   placeholder="Describe key functional tests, label standards, or finish requirements..."
                   className="w-full bg-gray-50 border border-gray-100 rounded-[40px] py-8 px-10 focus:bg-white focus:border-blue-500 outline-none text-xs font-semibold h-48 transition-all shadow-inner resize-none leading-relaxed"
                   value={formData.specialInstructions}
                   onChange={e => setFormData({...formData, specialInstructions: e.target.value})}
                 />
               </div>
            </div>
          </div>
        )}
      </div>

      <div className="pt-16">
        <button 
          type="submit" 
          disabled={isSubmitting}
          className="relative w-full py-8 bg-gray-900 text-white rounded-full font-black uppercase tracking-[0.4em] hover:bg-blue-600 transition-all text-[11px] shadow-3xl hover:shadow-blue-500/20 disabled:bg-gray-300 disabled:cursor-not-allowed group overflow-hidden"
        >
          <div className="relative z-10 flex items-center justify-center gap-4">
             {isSubmitting ? (
               <div className="flex items-center gap-3">
                 <div className="w-4 h-4 border-t-2 border-white rounded-full animate-spin"></div>
                 <span>Broadcasting Request...</span>
               </div>
             ) : (
               <div className="flex items-center gap-3">
                  <span>Authorize Protocol</span>
                  <ICONS.ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
               </div>
             )}
          </div>
          {isSubmitting && (
            <div className="absolute inset-0 bg-blue-600 flex items-center justify-center">
              <div className="w-20 h-1 overflow-hidden relative rounded-full">
                 <div className="absolute inset-0 bg-white/40 animate-shimmer" style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.8), transparent)', backgroundSize: '200% 100%' }}></div>
              </div>
            </div>
          )}
        </button>
        <p className="text-[9px] text-gray-400 text-center mt-8 font-black uppercase tracking-widest opacity-60">Security Encrypted Authorization Request</p>
      </div>
    </form>
  );
};

const FormInput: React.FC<{ label: string, value: any, onChange: (v: string) => void, type?: string, required?: boolean, placeholder?: string }> = ({ label, value, onChange, type = "text", required, placeholder }) => (
  <div className="space-y-5">
    <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 block ml-2">{label}</label>
    <input 
      type={type}
      required={required}
      placeholder={placeholder}
      className="w-full bg-gray-50 border border-gray-100 rounded-[28px] py-6 px-10 focus:bg-white focus:border-blue-500 outline-none text-xs font-black transition-all shadow-sm placeholder:text-gray-300"
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  </div>
);

export default RequestService;
