
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { store } from '../services/store';

const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [company, setCompany] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (isLogin) {
      const user = store.login(email);
      if (user) {
        store.setCurrentUser(user);
        navigate(user.role === 'CLIENT' ? '/dashboard' : '/admin');
      } else {
        setError('Credentials not found. Use admin@remaq.com, ops@remaq.com, or client@demo.com');
      }
    } else {
      // Signup logic simulation
      const newUser = { id: 'new-' + Date.now(), email, companyName: company, role: 'CLIENT' as const };
      store.setCurrentUser(newUser);
      navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-6 py-20">
      <div className="w-full max-w-md bg-white p-12 rounded-[40px] border border-gray-100">
        <h1 className="text-3xl font-bold tracking-tight mb-2 text-center">
          {isLogin ? 'Welcome Back' : 'Join Remaq'}
        </h1>
        <p className="text-gray-400 text-center mb-10 text-sm font-medium">
          {isLogin ? 'Access your supply chain command center' : 'Start managing your supply chain with precision'}
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && <p className="text-xs font-bold text-red-500 bg-red-50 p-4 rounded-xl text-center">{error}</p>}
          
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1">Email Address</label>
            <input 
              type="email" 
              required
              className="w-full bg-white border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:border-gray-900 transition-all font-medium"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="email@remaq.com"
            />
          </div>

          {!isLogin && (
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1">Company Name</label>
              <input 
                type="text" 
                required
                className="w-full bg-white border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:border-gray-900 transition-all font-medium"
                value={company}
                onChange={e => setCompany(e.target.value)}
              />
            </div>
          )}

          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1">Password</label>
            <input 
              type="password" 
              required
              className="w-full bg-white border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:border-gray-900 transition-all font-medium"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>

          <button type="submit" className="w-full py-5 bg-gray-900 text-white rounded-2xl font-bold hover:bg-black transition-all">
            {isLogin ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <div className="mt-10 pt-8 border-t border-gray-50 text-center">
           <button 
             onClick={() => setIsLogin(!isLogin)}
             className="text-xs font-bold text-gray-400 hover:text-gray-900 transition-colors uppercase tracking-widest"
           >
             {isLogin ? "Need a portal? Create an account" : "Existing client? Sign in"}
           </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
