
import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { store } from '../services/store';

const News: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const news = store.getPublishedContents('NEWS');
  const item = slug ? store.getContentBySlug(slug) : null;

  useEffect(() => {
    if (item) {
      document.title = item.metaTitle;
    } else {
      document.title = 'News | Remaq Supply Chain';
    }
    window.scrollTo(0, 0);
  }, [item]);

  if (slug && !item) {
    return (
      <div className="pt-40 pb-20 px-6 text-center">
        <h1 className="text-2xl font-bold mb-4">News Item Not Found</h1>
        <Link to="/news" className="text-gray-900 underline">Return to News</Link>
      </div>
    );
  }

  if (item) {
    return (
      <article className="pt-32 pb-40 px-6 max-w-3xl mx-auto">
        <Link to="/news" className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-gray-400 hover:text-gray-900 mb-12 transition-colors">
          <svg className="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
          Back to News
        </Link>
        
        <header className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 leading-tight text-gray-900">{item.title}</h1>
          <p className="text-gray-400 text-sm uppercase tracking-widest font-semibold">{new Date(item.createdAt).toLocaleDateString()}</p>
        </header>

        <img src={item.image} alt={item.title} className="w-full aspect-video object-cover rounded-[40px] mb-16" />

        <div className="prose prose-lg max-w-none text-gray-600 leading-relaxed space-y-8">
          {item.content.split('\n').map((para, i) => (
            <p key={i}>{para}</p>
          ))}
        </div>
      </article>
    );
  }

  return (
    <div className="pt-32 pb-40 px-6 max-w-5xl mx-auto">
      <header className="mb-24 text-center max-w-2xl mx-auto">
        <h1 className="text-5xl font-bold tracking-tight mb-6">Company News</h1>
        <p className="text-lg text-gray-500 leading-relaxed">
          The latest announcements and updates from the Remaq Global team.
        </p>
      </header>

      <div className="space-y-16">
        {news.map(item => (
          <Link key={item.id} to={`/news/${item.slug}`} className="group block py-12 border-b border-gray-100 first:border-t">
            <div className="flex flex-col md:flex-row gap-12 items-center">
              <div className="w-full md:w-64 flex-shrink-0 aspect-square overflow-hidden rounded-3xl bg-gray-50">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="flex-grow">
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 mb-4">{new Date(item.createdAt).toLocaleDateString()}</p>
                <h2 className="text-3xl font-bold mb-4 group-hover:text-gray-600 transition-colors leading-tight">{item.title}</h2>
                <p className="text-gray-500 text-sm leading-relaxed max-w-xl">
                  {item.excerpt}
                </p>
              </div>
              <div className="hidden md:block">
                 <div className="w-12 h-12 flex items-center justify-center rounded-full border border-gray-100 group-hover:border-gray-900 transition-colors">
                    <svg className="w-5 h-5 text-gray-300 group-hover:text-gray-900 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                 </div>
              </div>
            </div>
          </Link>
        ))}
        {news.length === 0 && (
          <div className="text-center py-20 text-gray-400">No news available at this time.</div>
        )}
      </div>
    </div>
  );
};

export default News;
