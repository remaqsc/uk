
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ICONS, COLORS } from '../constants';

const Home: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="pt-20 overflow-hidden page-enter">
      {/* Background Dynamics */}
      <div className="bg-blob top-[-15%] left-[-10%] opacity-20"></div>
      <div className="bg-blob bottom-[20%] right-[-15%] opacity-15" style={{ background: 'radial-gradient(circle, rgba(99, 102, 241, 0.15) 0%, transparent 70%)' }}></div>

      {/* Hero Section */}
      <section className="relative px-6 py-32 lg:py-56 max-w-7xl mx-auto text-center">
        <div className="animate-slide-up">
          <span className="inline-block px-5 py-2 mb-10 text-[10px] font-black uppercase tracking-[0.4em] text-blue-600 bg-blue-50/50 border border-blue-100 rounded-full animate-scale-in shadow-sm">
            Supply Chain Intelligence
          </span>
          <h1 className="text-6xl md:text-9xl font-black tracking-tighter mb-10 leading-[0.85] stagger-1">
            <span className="gradient-text">Supply Chain,</span> <br /> 
            <span className="text-gray-900">Simplified.</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-500 max-w-3xl mx-auto mb-16 leading-relaxed font-medium stagger-2">
            Managing global sourcing, multi-stage inspections, and door-to-door logistics with surgical precision.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-8 stagger-3">
            <button 
              onClick={() => navigate('/request')}
              className="w-full sm:w-auto px-14 py-6 bg-gray-900 text-white rounded-full text-xs font-black uppercase tracking-[0.2em] hover:bg-blue-600 transition-all shadow-2xl hover:shadow-blue-500/30 group active:scale-95"
            >
              Start New Project
              <ICONS.ArrowRight className="inline-block w-4 h-4 ml-4 group-hover:translate-x-1.5 transition-transform" />
            </button>
            <Link to="/tracking" className="w-full sm:w-auto px-12 py-6 glass border border-gray-200 text-gray-900 rounded-full text-xs font-black uppercase tracking-[0.2em] hover:border-gray-900 transition-all flex items-center justify-center group active:scale-95">
              <ICONS.Activity className="w-4 h-4 mr-4 text-blue-500 group-hover:animate-pulse" />
              Live Orbit
            </Link>
          </div>
        </div>
      </section>

      {/* Command Suite Grid */}
      <section className="bg-white/30 py-40 border-y border-gray-100 backdrop-blur-md relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none overflow-hidden">
           <div className="absolute top-1/2 left-0 w-64 h-64 bg-blue-100/20 blur-3xl rounded-full"></div>
           <div className="absolute top-1/4 right-0 w-96 h-96 bg-indigo-100/20 blur-3xl rounded-full"></div>
        </div>

        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="mb-24 text-center animate-slide-up">
             <h2 className="text-5xl font-black tracking-tighter mb-6">The Command Suite</h2>
             <p className="text-gray-400 text-lg font-medium">Precision integrated solutions for high-velocity brands.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            <ServiceCard 
              icon={<ICONS.Search className="w-8 h-8" />}
              title="Sourcing"
              description="Direct factory connections with verified audits and surgical cost control."
              color="blue"
              delay="stagger-1"
            />
            <ServiceCard 
              icon={<ICONS.Check className="w-8 h-8" />}
              title="Inspection"
              description="On-site verification and multi-point functional checks before any dispatch."
              color="indigo"
              delay="stagger-2"
            />
            <ServiceCard 
              icon={<ICONS.Ship className="w-8 h-8" />}
              title="Logistics"
              description="Optimized routing and real-time transit intelligence for global flows."
              color="emerald"
              delay="stagger-3"
            />
            <ServiceCard 
              icon={<ICONS.Box className="w-8 h-8" />}
              title="Scaling"
              description="Manufacturing management and inventory insights for rapid growth."
              color="amber"
              delay="stagger-4"
            />
          </div>
        </div>
      </section>

      {/* Modern Proof Section */}
      <section className="py-40 bg-gray-900 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-3/4 h-full bg-gradient-to-l from-blue-600/5 to-transparent pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <div className="animate-slide-up">
            <span className="inline-block px-4 py-1.5 mb-10 text-[10px] font-black uppercase tracking-[0.4em] text-blue-400 bg-white/5 border border-white/10 rounded-full">
              Infrastructure
            </span>
            <h2 className="text-6xl md:text-7xl font-black mb-12 tracking-tighter leading-[0.9]">Built for the <br /> <span className="text-blue-500">Next Decade.</span></h2>
            <div className="space-y-12">
              <AdvantageItem title="Cloud-Native Ops" description="Access your entire supply chain status from any device, anywhere." iconColor="text-blue-500" />
              <AdvantageItem title="Verified Logistics" description="Every milestone is double-verified by local boots-on-the-ground." iconColor="text-indigo-500" />
              <AdvantageItem title="Margin Protection" description="Eliminate middleman costs by going direct with Remaq management." iconColor="text-emerald-500" />
            </div>
          </div>
          <div className="relative animate-float lg:pl-12">
            <div className="aspect-[4/5] bg-gradient-to-br from-gray-800 to-gray-950 rounded-[80px] p-2 shadow-3xl relative overflow-hidden border border-white/5 group">
              <img src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=1200" alt="Logistics Tech" className="w-full h-full object-cover rounded-[76px] opacity-40 group-hover:scale-105 transition-transform duration-1000" />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/20 to-transparent"></div>
              
              <div className="absolute bottom-16 left-16 right-16 glass-dark p-10 rounded-[48px] border border-white/10 shadow-2xl">
                <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em] mb-4">Network Reliability</p>
                <div className="flex items-end justify-between mb-4">
                  <p className="text-5xl font-black text-white tracking-tighter">99.9%</p>
                  <span className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-lg">LIVE</span>
                </div>
                <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-full w-[99.9%] shadow-[0_0_20px_#3b82f6]"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

const ServiceCard: React.FC<{ icon: React.ReactNode, title: string, description: string, color: string, delay: string }> = ({ icon, title, description, color, delay }) => {
  const colorMap: any = {
    blue: 'text-blue-500 bg-blue-50/50 group-hover:bg-blue-600',
    indigo: 'text-indigo-500 bg-indigo-50/50 group-hover:bg-indigo-600',
    emerald: 'text-emerald-500 bg-emerald-50/50 group-hover:bg-emerald-600',
    amber: 'text-amber-500 bg-amber-50/50 group-hover:bg-amber-600',
  };

  return (
    <div className={`p-12 bg-white border border-gray-100 rounded-[56px] hover-card group animate-slide-up ${delay}`}>
      <div className={`w-16 h-16 rounded-[24px] flex items-center justify-center mb-10 transition-all duration-700 ${colorMap[color] || 'text-gray-900 bg-gray-50 group-hover:bg-gray-900'} group-hover:text-white group-hover:rotate-6 group-hover:shadow-lg`}>
        {icon}
      </div>
      <h3 className="text-2xl font-black mb-5 tracking-tighter group-hover:text-blue-600 transition-colors">{title}</h3>
      <p className="text-gray-400 text-sm font-medium leading-relaxed">{description}</p>
    </div>
  );
};

const AdvantageItem: React.FC<{ title: string, description: string, iconColor: string }> = ({ title, description, iconColor }) => (
  <div className="flex gap-10 group">
    <div className={`flex-shrink-0 w-10 h-10 mt-1 ${iconColor} transition-all duration-500 group-hover:scale-125 group-hover:rotate-12`}>
      <ICONS.Check className="w-10 h-10" />
    </div>
    <div>
      <h4 className="text-2xl font-black mb-3 text-white tracking-tight">{title}</h4>
      <p className="text-gray-400 text-base font-medium leading-relaxed max-w-sm">{description}</p>
    </div>
  </div>
);

export default Home;
