
import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { store } from '../services/store';
import { ICONS } from '../constants';

const Blog: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const posts = store.getPublishedContents('BLOG');
  const post = slug ? store.getContentBySlug(slug) : null;

  useEffect(() => {
    if (post) {
      document.title = post.metaTitle;
      // In a real SEO environment, we would inject meta tags here.
    } else {
      document.title = 'Blog | Remaq Supply Chain';
    }
    window.scrollTo(0, 0);
  }, [post]);

  if (slug && !post) {
    return (
      <div className="pt-40 pb-20 px-6 text-center">
        <h1 className="text-2xl font-bold mb-4">Article Not Found</h1>
        <Link to="/blog" className="text-gray-900 underline">Return to Blog</Link>
      </div>
    );
  }

  if (post) {
    return (
      <article className="pt-32 pb-40 px-6 max-w-3xl mx-auto">
        <Link to="/blog" className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-gray-400 hover:text-gray-900 mb-12 transition-colors">
          <svg className="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
          Back to Insights
        </Link>
        
        <header className="mb-12">
          <span className="inline-block px-3 py-1 bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500 rounded-full mb-6">
            {post.category}
          </span>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 leading-tight text-gray-900">{post.title}</h1>
          <p className="text-gray-400 text-sm uppercase tracking-widest font-semibold">{new Date(post.createdAt).toLocaleDateString()}</p>
        </header>

        <img src={post.image} alt={post.title} className="w-full aspect-video object-cover rounded-[40px] mb-16" />

        <div className="prose prose-lg max-w-none text-gray-600 leading-relaxed space-y-8">
          {post.content.split('\n').map((para, i) => (
            <p key={i}>{para}</p>
          ))}
        </div>
      </article>
    );
  }

  return (
    <div className="pt-32 pb-40 px-6 max-w-7xl mx-auto">
      <header className="mb-24 text-center max-w-2xl mx-auto">
        <h1 className="text-5xl font-bold tracking-tight mb-6">Insights</h1>
        <p className="text-xl text-gray-500 leading-relaxed">
          Deep dives into manufacturing, logistics, and global sourcing strategies for modern brands.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-20">
        {posts.map(post => (
          <Link key={post.id} to={`/blog/${post.slug}`} className="group block">
            <div className="aspect-[16/10] overflow-hidden rounded-[32px] mb-8 relative bg-gray-100">
              <img 
                src={post.image} 
                alt={post.title} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <span className="absolute top-6 left-6 px-4 py-1.5 bg-white/90 backdrop-blur rounded-full text-[10px] font-bold uppercase tracking-wider text-gray-900">
                {post.category}
              </span>
            </div>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 mb-4">{new Date(post.createdAt).toLocaleDateString()}</p>
            <h2 className="text-2xl font-bold mb-4 group-hover:text-gray-600 transition-colors leading-tight">{post.title}</h2>
            <p className="text-gray-500 text-sm leading-relaxed mb-8 line-clamp-2">
              {post.excerpt}
            </p>
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-900">
              Read Article <ICONS.ArrowRight className="w-4 h-4" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Blog;
