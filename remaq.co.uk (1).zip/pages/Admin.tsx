
import React, { useState, useMemo } from 'react';
import { store } from '../services/store';
import { ICONS, COLORS } from '../constants';
import { ShipmentStatus, SupportRequest, ContentPost, ContentType, ContentStatus, Invoice, Shipment, User } from '../types';

type DateFilter = 'Today' | '7Days' | 'ThisMonth' | 'LastMonth' | 'Custom';

const Admin: React.FC = () => {
  const user = store.getCurrentUser();
  const [activeView, setActiveView] = useState<'Overview' | 'Accounting' | 'Invoices' | 'Shipments' | 'Requests' | 'Content'>('Overview');
  const [dateFilter, setDateFilter] = useState<DateFilter>('ThisMonth');
  const [customRange, setCustomRange] = useState<{ start: string, end: string }>({ start: '', end: '' });

  if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
    return <div className="pt-40 text-center">Unauthorized access.</div>;
  }

  const isSuper = user.role === 'SUPER_ADMIN';

  const dateRange = useMemo(() => {
    const now = new Date();
    let start: Date | undefined;
    let end: Date | undefined = new Date();
    end.setHours(23, 59, 59, 999);

    switch (dateFilter) {
      case 'Today':
        start = new Date(now.setHours(0, 0, 0, 0));
        break;
      case '7Days':
        start = new Date();
        start.setDate(now.getDate() - 7);
        break;
      case 'ThisMonth':
        start = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'LastMonth':
        start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        end = new Date(now.getFullYear(), now.getMonth(), 0);
        break;
      case 'Custom':
        if (customRange.start) start = new Date(customRange.start);
        if (customRange.end) end = new Date(customRange.end);
        break;
      default:
        start = undefined;
        end = undefined;
    }
    return { start, end };
  }, [dateFilter, customRange]);

  const stats = store.getAccountingStats(dateRange.start, dateRange.end);

  return (
    <div className="pt-28 pb-20 px-6 max-w-7xl mx-auto min-h-screen">
      <header className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-16 gap-8 animate-slide-up">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className={`w-3 h-3 rounded-full ${isSuper ? 'bg-indigo-500 shadow-[0_0_10px_#6366f1]' : 'bg-blue-500 shadow-[0_0_10px_#3b82f6]'}`}></div>
            <h1 className="text-3xl font-black tracking-tight">{isSuper ? 'Global Super Admin' : 'Operation Command'}</h1>
          </div>
          <p className="text-gray-400 text-[10px] font-black uppercase tracking-[0.3em] ml-6">{user.companyName} Core System</p>
        </div>

        <div className="flex flex-col gap-4 w-full lg:w-auto">
          <div className="flex flex-wrap gap-2 glass p-1.5 rounded-2xl border border-gray-100 shadow-sm overflow-x-auto">
            <NavBtn active={activeView === 'Overview'} onClick={() => setActiveView('Overview')} label="Overview" />
            {isSuper && <NavBtn active={activeView === 'Accounting'} onClick={() => setActiveView('Accounting')} label="Ledger" />}
            <NavBtn active={activeView === 'Requests'} onClick={() => setActiveView('Requests')} label="Signals" />
            <NavBtn active={activeView === 'Invoices'} onClick={() => setActiveView('Invoices')} label="Billing" />
            <NavBtn active={activeView === 'Shipments'} onClick={() => setActiveView('Shipments')} label="Transit" />
            <NavBtn active={activeView === 'Content'} onClick={() => setActiveView('Content')} label="Brand" />
          </div>

          {isSuper && (activeView === 'Overview' || activeView === 'Accounting') && (
            <div className="flex flex-wrap items-center gap-4 bg-white/50 p-2 rounded-2xl border border-gray-100 self-end">
              <span className="text-[9px] font-black uppercase tracking-widest text-gray-400 ml-2">Period:</span>
              <FilterBtn active={dateFilter === 'Today'} onClick={() => setDateFilter('Today')} label="Today" />
              <FilterBtn active={dateFilter === '7Days'} onClick={() => setDateFilter('7Days')} label="7D" />
              <FilterBtn active={dateFilter === 'ThisMonth'} onClick={() => setDateFilter('ThisMonth')} label="Month" />
              <FilterBtn active={dateFilter === 'LastMonth'} onClick={() => setDateFilter('LastMonth')} label="Prev" />
              <FilterBtn active={dateFilter === 'Custom'} onClick={() => setDateFilter('Custom')} label="Custom" />
              
              {dateFilter === 'Custom' && (
                <div className="flex gap-2 animate-scale-in">
                  <input 
                    type="date" 
                    className="text-[10px] bg-white border border-gray-100 rounded-lg px-2 py-1 outline-none"
                    value={customRange.start}
                    onChange={e => setCustomRange({...customRange, start: e.target.value})}
                  />
                  <input 
                    type="date" 
                    className="text-[10px] bg-white border border-gray-100 rounded-lg px-2 py-1 outline-none"
                    value={customRange.end}
                    onChange={e => setCustomRange({...customRange, end: e.target.value})}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      </header>

      <div className="animate-slide-up stagger-1">
        {activeView === 'Overview' && <Overview isSuper={isSuper} stats={stats} />}
        {activeView === 'Accounting' && isSuper && <AccountingView stats={stats} />}
        {activeView === 'Requests' && <RequestManager />}
        {activeView === 'Invoices' && <InvoiceManager isSuper={isSuper} />}
        {activeView === 'Shipments' && <ShipmentManager />}
        {activeView === 'Content' && <ContentManager />}
      </div>
    </div>
  );
};

const NavBtn: React.FC<{ active: boolean, onClick: () => void, label: string }> = ({ active, onClick, label }) => (
  <button 
    onClick={onClick}
    className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${active ? 'bg-gray-900 text-white shadow-lg' : 'text-gray-400 hover:text-gray-900'}`}
  >
    {label}
  </button>
);

const FilterBtn: React.FC<{ active: boolean, onClick: () => void, label: string }> = ({ active, onClick, label }) => (
  <button 
    onClick={onClick}
    className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${active ? 'bg-blue-600 text-white shadow-md' : 'text-gray-400 hover:bg-gray-100'}`}
  >
    {label}
  </button>
);

const MetricCard: React.FC<{ label: string, value: string, trend?: string, color?: 'blue' | 'indigo' | 'emerald' | 'amber' }> = ({ label, value, trend, color = 'blue' }) => {
  const colorMap = {
    blue: 'text-blue-600',
    indigo: 'text-indigo-600',
    emerald: 'text-emerald-600',
    amber: 'text-amber-600',
  };

  return (
    <div className="bg-white p-10 rounded-[40px] border border-gray-100 shadow-sm hover-card">
      <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-6">{label}</p>
      <div className="flex items-baseline justify-between">
        <h3 className={`text-4xl font-black ${colorMap[color]}`}>{value}</h3>
        {trend && (
          <span className={`text-[10px] font-black uppercase px-2 py-1 rounded-lg ${trend.startsWith('+') ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-50 text-gray-400'}`}>
            {trend}
          </span>
        )}
      </div>
    </div>
  );
};

const Overview: React.FC<{ isSuper: boolean, stats: any }> = ({ isSuper, stats }) => {
  const requests = store.getRequests();
  const shipments = store.getShipments();
  
  return (
    <div className="space-y-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {isSuper && <MetricCard label="Total Revenue" value={`$${(stats.totalRevenue/1000).toFixed(1)}k`} trend="+14.2%" color="blue" />}
        {isSuper && <MetricCard label="Net Profit" value={`$${(stats.profit/1000).toFixed(1)}k`} trend="+11.5%" color="emerald" />}
        <MetricCard label="Transit Load" value={stats.activeShipments.toString()} trend="Active" color="indigo" />
        <MetricCard label="Incoming Signals" value={stats.incomingSignals.toString()} trend="New" color="amber" />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="bg-white p-12 rounded-[56px] border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-10">
            <h4 className="text-sm font-black uppercase tracking-[0.2em] text-gray-900">Recent Signals</h4>
            <ICONS.Activity className="w-5 h-5 text-amber-500" />
          </div>
          <div className="space-y-6 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
             {requests.slice(0, 10).map(r => (
               <div key={r.id} className="group flex justify-between items-center py-5 border-b border-gray-50 last:border-0 hover:translate-x-1 transition-transform cursor-pointer">
                 <div>
                   <p className="text-sm font-black text-gray-900 group-hover:text-blue-600 transition-colors">{r.companyName}</p>
                   <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{r.type}</p>
                 </div>
                 <span className="text-[9px] font-black uppercase tracking-widest text-blue-500 bg-blue-50 px-3 py-1 rounded-full">{r.status}</span>
               </div>
             ))}
          </div>
        </div>
        <div className="bg-white p-12 rounded-[56px] border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-10">
            <h4 className="text-sm font-black uppercase tracking-[0.2em] text-gray-900">Active Transit Flow</h4>
            <ICONS.Ship className="w-5 h-5 text-indigo-500" />
          </div>
          <div className="space-y-8 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
             {shipments.filter(s => s.status !== ShipmentStatus.DELIVERED).slice(0, 8).map(s => (
               <div key={s.id} className="py-2">
                 <div className="flex justify-between items-center mb-3">
                   <p className="text-xs font-black text-gray-900">{s.trackingNumber}</p>
                   <span className="text-[10px] font-black text-indigo-600">{s.progress}%</span>
                 </div>
                 <div className="w-full bg-gray-50 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-indigo-500 to-blue-500 h-full transition-all duration-1000" style={{ width: `${s.progress}%` }}></div>
                 </div>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const AccountingView: React.FC<{ stats: any }> = ({ stats }) => {
  return (
    <div className="space-y-12 animate-slide-up">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-gray-900 p-10 rounded-[48px] text-white shadow-2xl relative overflow-hidden group">
           <div className="absolute top-[-20%] right-[-10%] w-64 h-64 bg-blue-500/10 rounded-full blur-3xl group-hover:bg-blue-500/20 transition-colors"></div>
           <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-6 relative">Consolidated Revenue</p>
           <h3 className="text-5xl font-black relative tracking-tighter">${stats.totalRevenue.toLocaleString()}</h3>
           <p className="text-[9px] font-bold text-emerald-400 mt-4 relative uppercase">Global Distribution Yield</p>
        </div>
        <div className="bg-white p-10 rounded-[48px] border border-gray-100 shadow-sm group">
           <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-6">Operational Burn</p>
           <h3 className="text-5xl font-black text-red-500 tracking-tighter">-${stats.totalCosts.toLocaleString()}</h3>
           <p className="text-[9px] font-bold text-gray-400 mt-4 uppercase">Infrastructure Cost Control</p>
        </div>
        <div className="bg-white p-10 rounded-[48px] border border-emerald-50 shadow-sm relative overflow-hidden">
           <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl"></div>
           <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-6">Net Yield</p>
           <h3 className="text-5xl font-black text-emerald-600 tracking-tighter">${stats.profit.toLocaleString()}</h3>
           <p className="text-[9px] font-bold text-emerald-500 mt-4 uppercase">Verified Retained Growth</p>
        </div>
      </div>

      <div className="bg-white p-12 rounded-[64px] border border-gray-100 overflow-hidden shadow-sm">
        <div className="flex items-center justify-between mb-12">
            <h4 className="text-sm font-black uppercase tracking-[0.3em] text-gray-900">Historical Signal Data</h4>
            <div className="px-4 py-2 bg-gray-50 rounded-xl text-[10px] font-black uppercase tracking-widest text-gray-400 border border-gray-100">Live Pulse</div>
        </div>
        <div className="space-y-8">
          <div className="grid grid-cols-4 gap-4 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] border-b border-gray-50 pb-6 px-4">
             <span>Metric Block</span>
             <span className="text-right">Flow</span>
             <span className="text-right">Efficiency</span>
             <span className="text-right">Net Value</span>
          </div>
          {[
            { period: 'Strategic Sourcing', rev: 45000, exp: 38000, pro: 7000, color: 'emerald' },
            { period: 'Express Transit', rev: 128000, exp: 110000, pro: 18000, color: 'blue' },
            { period: 'Quality Verification', rev: 12000, exp: 9000, pro: 3000, color: 'amber' }
          ].map((row, i) => (
            <div key={i} className="grid grid-cols-4 gap-4 items-center px-4 group hover:bg-gray-50 py-4 rounded-2xl transition-colors">
               <span className="text-sm font-black text-gray-900">{row.period}</span>
               <span className="text-sm font-bold text-gray-500 text-right">${row.rev.toLocaleString()}</span>
               <span className="text-sm font-bold text-red-400 text-right">-${row.exp.toLocaleString()}</span>
               <span className={`text-sm font-black text-${row.color}-600 text-right`}>${row.pro.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const InvoiceManager: React.FC<{ isSuper: boolean }> = ({ isSuper }) => {
  const [invoices, setInvoices] = useState(store.getInvoices());
  const [editing, setEditing] = useState<Invoice | null>(null);

  const handleCreate = () => {
    const newInv: Invoice = {
      id: `RMQ-INV-${new Date().getFullYear()}-${Math.floor(Math.random()*1000).toString().padStart(3, '0')}`,
      clientId: 'c1',
      clientName: 'Demo Client Ltd',
      productCost: 0,
      shippingCost: 0,
      inspectionCost: 0,
      miscFees: 0,
      totalAmount: 0,
      showBreakdown: true,
      status: 'Draft',
      lastUpdated: new Date().toISOString()
    };
    setEditing(newInv);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editing) {
      const total = editing.productCost + editing.shippingCost + editing.inspectionCost + editing.miscFees;
      const updated = { ...editing, totalAmount: total, lastUpdated: new Date().toISOString() };
      const exists = store.getInvoices().find(i => i.id === updated.id);
      if (exists) store.updateInvoice(updated);
      else store.addInvoice(updated);
      setInvoices(store.getInvoices());
      setEditing(null);
    }
  };

  return (
    <div className="space-y-10">
      <div className="flex justify-between items-center px-2">
         <h2 className="text-xl font-black text-gray-900 uppercase tracking-tighter">Billing Ledger</h2>
         <button onClick={handleCreate} className="px-10 py-4 bg-gray-900 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-full hover:bg-blue-600 transition-all shadow-xl hover:shadow-blue-200/50">Issue New</button>
      </div>

      <div className="bg-white rounded-[56px] border border-gray-100 overflow-hidden shadow-sm">
        <div className="max-h-[600px] overflow-y-auto custom-scrollbar">
          <table className="w-full text-left">
            <thead className="bg-gray-50/50 border-b border-gray-100 sticky top-0 z-10">
              <tr>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">ID</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Entity</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Yield</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">State</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {invoices.map(inv => (
                <tr key={inv.id} className="hover:bg-blue-50/20 transition-colors group">
                  <td className="px-12 py-8 font-black text-gray-900 text-xs">{inv.id}</td>
                  <td className="px-12 py-8 text-xs font-bold text-gray-500 uppercase tracking-tight">{inv.clientName}</td>
                  <td className="px-12 py-8 font-black text-xs text-gray-900">${inv.totalAmount.toLocaleString()}</td>
                  <td className="px-12 py-8">
                    <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${inv.status === 'Paid' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-amber-50 text-amber-600 border border-amber-100'}`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="px-12 py-8">
                    <button onClick={() => setEditing(inv)} className="text-[10px] font-black uppercase tracking-widest text-gray-900 group-hover:text-blue-600 border-b-2 border-transparent hover:border-blue-600 transition-all">Edit Record</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editing && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 glass backdrop-blur-md animate-scale-in">
          <form onSubmit={handleSave} className="bg-white w-full max-w-2xl p-16 rounded-[64px] border border-gray-100 shadow-2xl space-y-12">
            <div className="flex justify-between items-center">
               <h3 className="text-3xl font-black tracking-tight">Financial Issue</h3>
               <button type="button" onClick={() => setEditing(null)} className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-red-500 transition-colors">Discard Draft</button>
            </div>
            
            <div className="grid grid-cols-2 gap-10">
               <div className="space-y-3">
                 <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 ml-1">Entity Reference</label>
                 <select className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-5 px-8 text-xs font-black outline-none appearance-none cursor-pointer hover:bg-white transition-colors">
                    <option>{editing.clientName}</option>
                 </select>
               </div>
               <div className="space-y-3">
                 <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 ml-1">Payment State</label>
                 <select 
                   value={editing.status}
                   onChange={e => setEditing({...editing, status: e.target.value as any})}
                   className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-5 px-8 text-xs font-black outline-none appearance-none cursor-pointer hover:bg-white transition-colors"
                 >
                    <option value="Draft">Drafting</option>
                    <option value="Issued">Issued (Active)</option>
                    <option value="Paid">Verified Paid</option>
                 </select>
               </div>
            </div>

            <div className="grid grid-cols-2 gap-10">
               <AdminInp label="Factory Yield (Product)" value={editing.productCost} onChange={v => setEditing({...editing, productCost: Number(v)})} />
               <AdminInp label="Logistics Burn (Shipping)" value={editing.shippingCost} onChange={v => setEditing({...editing, shippingCost: Number(v)})} />
               <AdminInp label="QC Fee (Inspection)" value={editing.inspectionCost} onChange={v => setEditing({...editing, inspectionCost: Number(v)})} />
               <AdminInp label="Admin Margin (Misc)" value={editing.miscFees} onChange={v => setEditing({...editing, miscFees: Number(v)})} />
            </div>

            <div className="pt-12 border-t border-gray-50 flex items-center justify-between">
               <div>
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-2">Consolidated Due</p>
                  <p className="text-5xl font-black text-blue-600 tracking-tighter">${(editing.productCost + editing.shippingCost + editing.inspectionCost + editing.miscFees).toLocaleString()}</p>
               </div>
               <button type="submit" className="px-12 py-6 bg-gray-900 text-white rounded-full text-xs font-black uppercase tracking-[0.2em] hover:bg-blue-600 transition-all shadow-xl shadow-blue-500/10">Authorize Release</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

const RequestManager: React.FC = () => {
  const [requests, setRequests] = useState(store.getRequests());
  const [viewing, setViewing] = useState<SupportRequest | null>(null);

  const handleUpdate = (req: SupportRequest) => {
    store.updateRequest(req);
    setRequests(store.getRequests());
    setViewing(null);
  };

  return (
    <div className="space-y-10 animate-slide-up">
       <div className="bg-white rounded-[56px] border border-gray-100 overflow-hidden shadow-sm">
        <div className="max-h-[600px] overflow-y-auto custom-scrollbar">
          <table className="w-full text-left">
            <thead className="bg-gray-50/50 border-b border-gray-100 sticky top-0 z-10">
              <tr>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Signal Type</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Origin</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Date Logged</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Current Phase</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {requests.map(req => (
                <tr key={req.id} className="hover:bg-blue-50/20 transition-colors group">
                  <td className="px-12 py-8 font-black text-gray-900 text-xs">{req.type}</td>
                  <td className="px-12 py-8 text-xs font-bold text-gray-500 uppercase">{req.companyName}</td>
                  <td className="px-12 py-8 text-[10px] text-gray-400 font-black uppercase tracking-widest">{new Date(req.createdAt).toLocaleDateString()}</td>
                  <td className="px-12 py-8">
                    <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${req.status === 'Completed' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-blue-50 text-blue-600 border border-blue-100'}`}>
                      {req.status}
                    </span>
                  </td>
                  <td className="px-12 py-8">
                    <button onClick={() => setViewing(req)} className="text-[10px] font-black uppercase tracking-widest text-gray-900 group-hover:text-blue-600 border-b-2 border-transparent hover:border-blue-600 transition-all">Review Signal</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {viewing && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 glass animate-scale-in">
           <div className="bg-white w-full max-w-xl p-16 rounded-[64px] border border-gray-100 shadow-2xl space-y-12">
              <div className="flex justify-between items-center">
                 <h3 className="text-3xl font-black tracking-tight">{viewing.type} Brief</h3>
                 <button onClick={() => setViewing(null)} className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-gray-900">Close</button>
              </div>
              <div className="bg-gray-50 p-10 rounded-[40px] border border-gray-100 text-xs font-medium leading-relaxed text-gray-600 shadow-inner">
                {viewing.details}
              </div>
              <div className="space-y-4">
                 <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 ml-1">Update Execution Status</label>
                 <select 
                   value={viewing.status}
                   onChange={e => handleUpdate({...viewing, status: e.target.value as any})}
                   className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-5 px-8 text-xs font-black outline-none appearance-none cursor-pointer"
                 >
                    {['Pending Review', 'In Progress', 'Completed', 'Closed'].map(st => <option key={st} value={st}>{st}</option>)}
                 </select>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

const ShipmentManager: React.FC = () => {
  const [shipments, setShipments] = useState(store.getShipments());
  const [editing, setEditing] = useState<Shipment | null>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editing) {
      store.updateShipment(editing);
      setShipments(store.getShipments());
      setEditing(null);
    }
  };

  return (
    <div className="space-y-10 animate-slide-up">
      <div className="bg-white rounded-[56px] border border-gray-100 overflow-hidden shadow-sm">
        <div className="max-h-[600px] overflow-y-auto custom-scrollbar">
          <table className="w-full text-left">
            <thead className="bg-gray-50/50 border-b border-gray-100 sticky top-0 z-10">
              <tr>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Tracking Matrix</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Flow Level</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Phase</th>
                <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {shipments.map(s => (
                <tr key={s.id} className="hover:bg-indigo-50/20 transition-colors group">
                  <td className="px-12 py-8 font-black text-gray-900 text-xs">{s.trackingNumber}</td>
                  <td className="px-12 py-8">
                     <div className="w-32 bg-gray-100 h-2 rounded-full overflow-hidden shadow-inner">
                        <div className="bg-gradient-to-r from-indigo-500 to-blue-500 h-full transition-all duration-1000" style={{ width: `${s.progress}%` }}></div>
                     </div>
                     <span className="text-[9px] font-black text-indigo-600 mt-2 block">{s.progress}%</span>
                  </td>
                  <td className="px-12 py-8 text-xs text-gray-500 font-black uppercase tracking-widest">{s.status}</td>
                  <td className="px-12 py-8">
                     <button onClick={() => setEditing(s)} className="text-[10px] font-black uppercase tracking-widest text-gray-900 group-hover:text-indigo-600 border-b-2 border-transparent hover:border-indigo-600 transition-all">Command Updates</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editing && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 glass animate-scale-in">
           <form onSubmit={handleSave} className="bg-white w-full max-w-xl p-16 rounded-[64px] border border-gray-100 shadow-2xl space-y-12">
              <div className="flex justify-between items-center">
                 <h3 className="text-3xl font-black tracking-tight">Logistics Protocol</h3>
                 <button type="button" onClick={() => setEditing(null)} className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-gray-900">Close</button>
              </div>
              
              <div className="space-y-4">
                 <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 ml-1">Transit Milestone</label>
                 <select 
                   value={editing.status}
                   onChange={e => setEditing({...editing, status: e.target.value as any})}
                   className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-5 px-8 text-xs font-black outline-none appearance-none"
                 >
                    {Object.values(ShipmentStatus).map(st => <option key={st} value={st}>{st}</option>)}
                 </select>
              </div>

              <div className="space-y-4">
                 <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 ml-1">Operational Flow ({editing.progress}%)</label>
                 <input 
                   type="range" min="0" max="100" 
                   value={editing.progress} 
                   onChange={e => setEditing({...editing, progress: Number(e.target.value)})}
                   className="w-full accent-indigo-600 h-2 bg-gray-100 rounded-full cursor-pointer"
                 />
              </div>

              <div className="space-y-4">
                 <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 ml-1">Client Feed Note</label>
                 <textarea 
                   value={editing.clientNotes}
                   onChange={e => setEditing({...editing, clientNotes: e.target.value})}
                   className="w-full bg-gray-50 border border-gray-100 rounded-3xl py-6 px-8 text-xs font-medium h-32 outline-none shadow-inner resize-none"
                   placeholder="Direct status feed to client portal..."
                 />
              </div>

              <button type="submit" className="w-full py-6 bg-gray-900 text-white rounded-full text-xs font-black uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all shadow-xl shadow-indigo-500/10">Push Protocol Update</button>
           </form>
        </div>
      )}
    </div>
  );
};

const ContentManager: React.FC = () => {
  const [items, setItems] = useState(store.getContents());
  const [editing, setEditing] = useState<ContentPost | null>(null);

  const handleAddNew = (type: ContentType) => {
    const newItem: ContentPost = {
      id: `c-${Date.now()}`,
      type,
      title: '',
      slug: '',
      metaTitle: '',
      metaDescription: '',
      excerpt: '',
      content: '',
      image: '',
      category: type === 'BLOG' ? 'Strategy' : undefined,
      status: 'Draft',
      createdAt: new Date().toISOString()
    };
    setEditing(newItem);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editing) {
      const existing = store.getContents().find(i => i.id === editing.id);
      if (existing) store.updateContent(editing);
      else store.addContent(editing);
      setItems(store.getContents());
      setEditing(null);
    }
  };

  return (
    <div className="space-y-10 animate-slide-up">
      <div className="flex justify-between items-center px-2">
         <h2 className="text-xl font-black text-gray-900 uppercase tracking-tighter">Brand Narrative</h2>
         <div className="flex gap-4">
            <button onClick={() => handleAddNew('BLOG')} className="px-8 py-3.5 bg-gray-900 text-white text-[10px] font-black uppercase tracking-widest rounded-full hover:bg-blue-600 transition-all">New Strategy</button>
            <button onClick={() => handleAddNew('NEWS')} className="px-8 py-3.5 border border-gray-100 text-gray-900 text-[10px] font-black uppercase tracking-widest rounded-full hover:bg-gray-50 transition-all">New Bulletin</button>
         </div>
      </div>
      <div className="bg-white rounded-[56px] border border-gray-100 overflow-hidden shadow-sm">
        <table className="w-full text-left">
          <thead className="bg-gray-50/50 border-b border-gray-100">
            <tr>
              <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Format</th>
              <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Descriptor</th>
              <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">State</th>
              <th className="px-12 py-8 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {items.map(item => (
              <tr key={item.id} className="hover:bg-blue-50/20 transition-colors group">
                <td className="px-12 py-8"><span className="text-[10px] font-black uppercase tracking-widest text-blue-500 bg-blue-50 px-3 py-1 rounded-lg">{item.type}</span></td>
                <td className="px-12 py-8 font-black text-gray-900 text-xs">{item.title}</td>
                <td className="px-12 py-8"><span className="text-[10px] font-black uppercase tracking-widest text-gray-900">{item.status}</span></td>
                <td className="px-12 py-8">
                   <button onClick={() => setEditing(item)} className="text-[10px] font-black uppercase tracking-widest text-gray-900 group-hover:text-blue-600 border-b-2 border-transparent hover:border-blue-600 transition-all">Edit Asset</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 glass animate-scale-in">
           <form onSubmit={handleSave} className="bg-white w-full max-w-4xl p-20 rounded-[80px] border border-gray-100 shadow-2xl space-y-12 overflow-y-auto max-h-[90vh]">
              <div className="flex justify-between items-center mb-4">
                 <h3 className="text-4xl font-black tracking-tight">Asset Config</h3>
                 <button type="button" onClick={() => setEditing(null)} className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-red-500 transition-colors">Discard</button>
              </div>
              <div className="grid grid-cols-2 gap-10">
                <AdminInp label="Asset Heading" value={editing.title} onChange={v => setEditing({...editing, title: v})} />
                <AdminInp label="Media Reference (Image URL)" value={editing.image} onChange={v => setEditing({...editing, image: v})} />
              </div>
              <div className="space-y-4">
                <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 ml-1">Asset Narrative (Markdown)</label>
                <textarea 
                  className="w-full bg-gray-50 border border-gray-100 rounded-[40px] py-10 px-12 h-96 text-xs font-medium outline-none shadow-inner resize-none" 
                  value={editing.content}
                  onChange={e => setEditing({...editing, content: e.target.value})}
                  placeholder="Initiate brand signaling..."
                />
              </div>
              <button type="submit" className="w-full py-8 bg-gray-900 text-white rounded-full text-xs font-black uppercase tracking-[0.2em] hover:bg-blue-600 transition-all shadow-2xl shadow-blue-500/10">Authorize Publication</button>
           </form>
        </div>
      )}
    </div>
  );
};

const AdminInp: React.FC<{ label: string, value: any, onChange: (v: string) => void }> = ({ label, value, onChange }) => (
  <div className="space-y-3">
    <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 block ml-1">{label}</label>
    <input 
      type="text" 
      className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-5 px-8 text-xs font-black outline-none hover:bg-white focus:bg-white focus:border-blue-500 transition-all shadow-sm"
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  </div>
);

export default Admin;
