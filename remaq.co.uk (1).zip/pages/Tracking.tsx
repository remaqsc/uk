
import React, { useState } from 'react';
import { store } from '../services/store';
import { ICONS } from '../constants';

const Tracking: React.FC = () => {
  const [query, setQuery] = useState('');
  const [shipment, setShipment] = useState<any>(null);
  const [searched, setSearched] = useState(false);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    setIsSearching(true);
    // Sophisticated data signal simulation
    await new Promise(r => setTimeout(r, 1200)); 
    
    const result = store.getShipmentById(query.trim());
    setShipment(result || null);
    setSearched(true);
    setIsSearching(false);
  };

  return (
    <div className="pt-32 pb-40 px-6 max-w-5xl mx-auto flex flex-col items-center min-h-screen relative page-enter">
      <div className="bg-blob top-[15%] left-[-15%] scale-150 opacity-20"></div>
      
      <div className="w-full max-w-2xl text-center mb-28 animate-slide-up">
        <span className="inline-block px-4 py-1.5 mb-8 text-[10px] font-black uppercase tracking-[0.3em] text-blue-600 bg-blue-50/50 border border-blue-100 rounded-full">
          Global Monitoring System
        </span>
        <h1 className="text-5xl md:text-6xl font-black tracking-tight mb-8">Visual Orbit</h1>
        <p className="text-gray-500 text-lg mb-14 font-medium max-w-lg mx-auto leading-relaxed">
          Access the real-time location and status of your global supply chain assets.
        </p>

        <form onSubmit={handleSearch} className="relative group animate-scale-in max-w-xl mx-auto">
          {/* Subtle Glow Effect */}
          <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full blur opacity-10 group-focus-within:opacity-25 transition duration-500"></div>
          
          <div className="relative">
            <input 
              type="text" 
              placeholder="Enter Remaq Tracking ID"
              className="w-full bg-white border border-gray-100 rounded-full py-7 px-10 focus:outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/5 transition-all text-sm font-bold shadow-[0_10px_30px_-10px_rgba(0,0,0,0.05)]"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            {/* Clickable Action Button with high z-index */}
            <button 
              type="submit" 
              disabled={isSearching}
              className="absolute right-3 top-3 bottom-3 z-10 bg-gray-900 text-white rounded-full px-12 text-[10px] font-black uppercase tracking-[0.2em] hover:bg-blue-600 active:bg-blue-700 transition-all shadow-lg active:scale-95 disabled:bg-gray-300 disabled:cursor-not-allowed group"
            >
              {isSearching ? (
                <div className="flex items-center gap-2">
                   <div className="w-3 h-3 border-t-2 border-white rounded-full animate-spin"></div>
                   <span>Syncing...</span>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span>Track Signal</span>
                  <ICONS.ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </div>
              )}
            </button>
          </div>
        </form>

        {searched && !shipment && !isSearching && (
          <div className="mt-12 p-8 border border-red-100 rounded-[32px] bg-red-50/20 text-[10px] text-red-500 font-black uppercase tracking-[0.3em] animate-scale-in">
            Invalid Tracking ID. Verification Failed.
          </div>
        )}
      </div>

      {shipment && !isSearching && (
        <div className="w-full space-y-12 animate-slide-up stagger-1">
          {/* Main Delivery Card */}
          <div className="w-full p-20 glass border border-white rounded-[64px] text-center relative overflow-hidden group shadow-xl shadow-blue-500/5">
            <div className="absolute top-0 right-0 p-12 opacity-[0.04] rotate-12 group-hover:scale-110 transition-transform duration-1000">
               <ICONS.Ship className="w-72 h-72" />
            </div>
            <span className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-500 mb-8 block">Projected Arrival</span>
            <h2 className="text-6xl md:text-7xl font-black text-gray-900 tracking-tighter mb-6">Feb 18 – Feb 22</h2>
            <div className="flex items-center justify-center gap-3">
               <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_10px_#10b981]"></span>
               <span className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.3em]">Payload active and healthy</span>
            </div>
          </div>

          {/* Detailed Progress Stats */}
          <div className="w-full bg-white p-16 rounded-[56px] border border-gray-50 shadow-sm relative overflow-hidden group">
            <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-50/50 rounded-full blur-3xl group-hover:bg-indigo-50 transition-colors"></div>
            
            <div className="flex justify-between items-end mb-12 px-2 relative z-10">
              <div>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 block mb-3">Operational Milestone</span>
                <span className="text-2xl font-black text-gray-900 uppercase tracking-tight">{shipment.status}</span>
              </div>
              <div className="text-right">
                <span className="text-5xl font-black text-blue-600 tracking-tighter">{shipment.progress}%</span>
              </div>
            </div>

            <div className="w-full bg-gray-50 h-3 rounded-full overflow-hidden relative mb-2 z-10 shadow-inner">
              <div 
                className="bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 h-full transition-all duration-1500 ease-out relative" 
                style={{ width: `${shipment.progress}%` }}
              >
                 <div className="absolute inset-0 bg-white/20 animate-shimmer" style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)', backgroundSize: '200% 100%' }}></div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mt-20 pt-16 border-t border-gray-50 relative z-10">
              <div className="flex gap-8 group/item">
                <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center flex-shrink-0 transition-transform group-hover/item:scale-110">
                  <ICONS.Activity className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 block mb-3">Live Logs</span>
                  <div className="inline-block px-5 py-2 bg-gray-900 text-white rounded-full text-[10px] font-black uppercase tracking-widest">
                    {shipment.status}
                  </div>
                </div>
              </div>
              <div className="flex gap-8 group/item">
                <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center flex-shrink-0 transition-transform group-hover/item:scale-110">
                  <ICONS.Box className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 block mb-3">Intelligence Feed</span>
                  <p className="text-sm text-gray-600 leading-relaxed font-semibold">
                    {shipment.clientNotes}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Tracking;
