
import { User, Shipment, Invoice, ContentPost, SupportRequest, ShipmentStatus, Role } from '../types';

// Initial Mock Data
const MOCK_SUPER_ADMIN: User = { id: 'sa1', email: 'admin@remaq.com', companyName: 'Remaq Global', role: 'SUPER_ADMIN' };
const MOCK_ADMIN: User = { id: 'a1', email: 'ops@remaq.com', companyName: 'Remaq Operations', role: 'ADMIN' };
const MOCK_CLIENT: User = { id: 'c1', email: 'client@demo.com', companyName: 'Demo Client Ltd', role: 'CLIENT' };

let currentUser: User | null = null;

// Generator for mock data
const generateMockData = () => {
  const shipmentsArr: Shipment[] = [];
  const invoicesArr: Invoice[] = [];
  const requestsArr: SupportRequest[] = [];
  
  // Create 70+ orders for January
  for (let i = 1; i <= 75; i++) {
    const day = Math.floor(Math.random() * 31) + 1;
    const dateStr = `2024-01-${day.toString().padStart(2, '0')}`;
    const id = `RMQ-JAN-${i.toString().padStart(3, '0')}`;
    const productCost = Math.floor(Math.random() * 5000) + 1000;
    const shippingCost = Math.floor(Math.random() * 2000) + 500;
    const inspectionCost = 300;
    const total = productCost + shippingCost + inspectionCost;

    invoicesArr.push({
      id: `INV-${id}`,
      clientId: 'c1',
      clientName: 'Demo Client Ltd',
      productCost,
      shippingCost,
      inspectionCost,
      miscFees: Math.floor(total * 0.05),
      totalAmount: Math.floor(total * 1.05),
      showBreakdown: true,
      status: 'Paid',
      issuedDate: dateStr,
      paidDate: dateStr,
      lastUpdated: dateStr
    });

    shipmentsArr.push({
      id: `s-jan-${i}`,
      invoiceId: `INV-${id}`,
      trackingNumber: `RMQ-TRK-JAN${i.toString().padStart(3, '0')}`,
      clientId: 'c1',
      status: ShipmentStatus.DELIVERED,
      progress: 100,
      lastUpdate: dateStr,
      adminNotes: 'Legacy January Shipment',
      clientNotes: 'Successfully delivered in January cycle.'
    });
  }

  // Add some recent ones for Feb/Current
  for (let i = 1; i <= 15; i++) {
    const date = new Date();
    date.setDate(date.getDate() - Math.floor(Math.random() * 10));
    const dateStr = date.toISOString().split('T')[0];
    const id = `RMQ-FEB-${i.toString().padStart(3, '0')}`;
    const total = Math.floor(Math.random() * 10000) + 5000;

    invoicesArr.push({
      id: `INV-${id}`,
      clientId: 'c1',
      clientName: 'Demo Client Ltd',
      productCost: total * 0.7,
      shippingCost: total * 0.2,
      inspectionCost: total * 0.05,
      miscFees: total * 0.05,
      totalAmount: total,
      showBreakdown: true,
      status: i % 3 === 0 ? 'Issued' : 'Paid',
      issuedDate: dateStr,
      lastUpdated: dateStr
    });

    shipmentsArr.push({
      id: `s-feb-${i}`,
      invoiceId: `INV-${id}`,
      trackingNumber: `RMQ-TRK-FEB${i.toString().padStart(3, '0')}`,
      clientId: 'c1',
      status: i % 2 === 0 ? ShipmentStatus.IN_TRANSIT : ShipmentStatus.QUALITY_CHECK,
      progress: Math.floor(Math.random() * 90),
      lastUpdate: dateStr,
      adminNotes: 'Active Spring Batch',
      clientNotes: 'En route to destination hub.'
    });
  }

  // Generate some requests
  for (let i = 1; i <= 20; i++) {
    requestsArr.push({
      id: `REQ-${i}`,
      clientId: 'c1',
      companyName: 'Demo Client Ltd',
      email: 'client@demo.com',
      type: i % 3 === 0 ? 'Sourcing' : i % 2 === 0 ? 'Shipping' : 'Inspection',
      details: 'Automated signal ' + i,
      formData: {},
      status: i % 4 === 0 ? 'Completed' : 'Pending Review',
      createdAt: new Date(Date.now() - Math.random() * 1000000000).toISOString()
    });
  }

  return { shipmentsArr, invoicesArr, requestsArr };
};

const mockData = generateMockData();
let shipments: Shipment[] = mockData.shipmentsArr;
let invoices: Invoice[] = mockData.invoicesArr;
let requests: SupportRequest[] = mockData.requestsArr;

let contents: ContentPost[] = [
  // BLOGS
  {
    id: 'b1',
    type: 'BLOG',
    title: 'The Future of Direct Factory Sourcing',
    slug: 'future-of-direct-sourcing',
    metaTitle: 'Direct Sourcing Insights | Remaq',
    metaDescription: 'Discover why top brands are moving away from middle-men to direct factory connections.',
    excerpt: 'In 2024, the landscape of global manufacturing is shifting towards radical transparency and direct engagement.',
    content: 'The old model of supply chain management relied heavily on multiple layers of intermediaries. Today, technology has bridged the gap between brand owners and manufacturing floors. At Remaq, we emphasize the "Direct Protocol"—a strategy that eliminates unnecessary markup and communication lag.\n\nBy establishing a direct line, brands can ensure their quality standards are met at the source. This transparency allows for faster iteration, better material control, and ultimately, a more agile response to market trends. We explore how digital tools are making this easier than ever.',
    image: 'https://images.unsplash.com/photo-1565034946487-077786996e27?q=80&w=1200&auto=format&fit=crop',
    category: 'Strategy',
    status: 'Published',
    createdAt: '2024-02-10T10:00:00Z'
  },
  {
    id: 'b2',
    type: 'BLOG',
    title: 'Precision in Quality Control: Beyond the Checklist',
    slug: 'precision-quality-control',
    metaTitle: 'QC Standards & Precision | Remaq',
    metaDescription: 'Learn how multi-point functional audits prevent costly production delays.',
    excerpt: 'Quality is not a final destination, but a continuous signal maintained throughout production.',
    content: 'Many companies view quality control as a "pass/fail" event at the end of a production run. However, true precision requires intermittent verification. Our Quality Shield program integrates functional checks at the 30%, 50%, and 100% marks of manufacturing.\n\nThis approach identifies defects before they are multiplied across an entire batch. From tensile strength testing to aesthetic finish audits, we look at the microscopic details that define a premium product. Protecting your brand means protecting your output.',
    image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=1200&auto=format&fit=crop',
    category: 'Quality',
    status: 'Published',
    createdAt: '2024-02-05T14:30:00Z'
  },
  {
    id: 'b3',
    type: 'BLOG',
    title: 'Navigating Global Freight in 2024',
    slug: 'navigating-global-freight',
    metaTitle: 'Global Freight Trends 2024 | Remaq',
    metaDescription: 'An analysis of sea vs air express costs and transit intelligence for modern brands.',
    excerpt: 'Volatility in shipping lanes requires a smarter, data-driven approach to logistics.',
    content: 'Shipping is no longer just about getting a box from A to B; it is about transit intelligence. With fluctuating fuel surcharges and varying port congestion, brands must choose their lanes wisely. Sea economy remains the king for volume, but Priority Sea is bridging the gap for high-growth electronics.\n\nWe analyze the current data on "Door-to-Door" efficiency and why digital tracking is now a requirement, not a luxury. Real-time signal monitoring allows logistics managers to pivot routes when delays are detected in the network.',
    image: 'https://images.unsplash.com/photo-1494412574743-01103bbd782b?q=80&w=1200&auto=format&fit=crop',
    category: 'Logistics',
    status: 'Published',
    createdAt: '2024-01-28T09:15:00Z'
  },
  {
    id: 'b4',
    type: 'BLOG',
    title: 'The Hidden ROI of Factory Audits',
    slug: 'roi-of-factory-audits',
    metaTitle: 'Why Factory Audits Matter | Remaq',
    metaDescription: 'Uncovering the long-term financial benefits of thorough manufacturer verification.',
    excerpt: 'A factory audit is an investment in your company\'s long-term stability and ethical reputation.',
    content: 'Initial price quotes are often a siren song that leads brands to unreliable partners. A Remaq audit looks past the pricing sheet into the factory\'s operational soul. We examine financial stability, worker conditions, and machine maintenance logs.\n\nWhen you know your manufacturer is built on solid ground, you reduce the risk of sudden bankruptcies or ethical scandals that can destroy a brand overnight. The ROI is measured in the headaches you *don\'t* have six months down the line.',
    image: 'https://images.unsplash.com/photo-1553413077-190dd305871c?q=80&w=1200&auto=format&fit=crop',
    category: 'Sourcing',
    status: 'Published',
    createdAt: '2024-01-15T11:00:00Z'
  },
  {
    id: 'b5',
    type: 'BLOG',
    title: 'Sustainable Supply Chains: A Necessity for Scale',
    slug: 'sustainable-supply-chains',
    metaTitle: 'Sustainability in Scale | Remaq',
    metaDescription: 'How reducing transit waste and optimizing manufacturing leads to better margins.',
    excerpt: 'Green logistics is no longer just a CSR initiative; it\'s a fiscal strategy.',
    content: 'Inefficiency in the supply chain is synonymous with waste. Over-packaging, empty container space, and poorly planned routes all contribute to a larger carbon footprint and smaller margins. By optimizing palletization and utilizing low-emission freight options, brands can actually lower their per-unit costs.\n\nSustainable sourcing also builds customer loyalty. Modern consumers are looking for a brand signal that indicates environmental responsibility. We show you how to scale without leaving a massive footprint behind.',
    image: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=1200&auto=format&fit=crop',
    category: 'Strategy',
    status: 'Published',
    createdAt: '2024-01-05T16:45:00Z'
  },

  // NEWS
  {
    id: 'n1',
    type: 'NEWS',
    title: 'Remaq Launches New Vietnam Operations Hub',
    slug: 'vietnam-operations-hub-launch',
    metaTitle: 'Remaq Expands to Vietnam | News',
    metaDescription: 'Announcing our new on-site inspection team and sourcing center in Ho Chi Minh City.',
    excerpt: 'Remaq expands its physical footprint to support the growing manufacturing sector in Southeast Asia.',
    content: 'To better serve our clients diversifying their production outside of China, Remaq is proud to announce the opening of our Vietnam Command Hub. Located in Ho Chi Minh City, this facility houses a dedicated team of quality engineers and sourcing specialists.\n\nThis expansion allows us to offer 24-hour turnaround on inspections across northern and southern Vietnam, ensuring our clients maintain the same level of precision they expect from our mainland operations.',
    image: 'https://images.unsplash.com/photo-1583417319070-4a69db38a482?q=80&w=1200&auto=format&fit=crop',
    status: 'Published',
    createdAt: '2024-02-12T08:00:00Z'
  },
  {
    id: 'n2',
    type: 'NEWS',
    title: 'Command Center 2.0: Major UI Update Released',
    slug: 'command-center-2-0-update',
    metaTitle: 'New UI: Command Center 2.0 | Remaq News',
    metaDescription: 'We have completely overhauled the client portal for faster tracking and cleaner project initialization.',
    excerpt: 'The Remaq digital experience just got a massive upgrade with a focus on futuristic minimalism.',
    content: 'Our digital engineering team has successfully deployed Command Center 2.0. This update introduces "Visual Orbit" tracking, allowing for more granular shipment data visualization.\n\nKey features include high-contrast data cards, a more intuitive service initialization flow, and enhanced security protocols for financial documents. We believe managing your supply chain should be as beautiful as it is efficient.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1200&auto=format&fit=crop',
    status: 'Published',
    createdAt: '2024-02-08T09:00:00Z'
  },
  {
    id: 'n3',
    type: 'NEWS',
    title: 'Remaq Surpasses 10,000 Successful QC Audits',
    slug: 'milestone-10k-qc-audits',
    metaTitle: '10,000 QC Audits Milestone | Remaq',
    metaDescription: 'Celebrating a major milestone in global quality assurance and manufacturer verification.',
    excerpt: 'A testament to our commitment to quality, we have reached a five-figure milestone in functional checks.',
    content: 'Today we celebrate the completion of our 10,000th on-site quality inspection. Since our inception, Remaq has focused on providing a reliable "boots on the ground" presence for brands worldwide.\n\nFrom smart electronics to high-end fashion, our team has protected over $500M in inventory from manufacturing defects. We thank our partners and dedicated staff for their unwavering pursuit of perfection.',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=1200&auto=format&fit=crop',
    status: 'Published',
    createdAt: '2024-01-20T12:00:00Z'
  },
  {
    id: 'n4',
    type: 'NEWS',
    title: 'Partnership: Remaq Joins Global Sustainability Alliance',
    slug: 'global-sustainability-alliance-partnership',
    metaTitle: 'Sustainability Partnership | Remaq News',
    metaDescription: 'Remaq commits to carbon-neutral transit goals by joining the GSA coalition.',
    excerpt: 'We are taking a major step towards greener logistics by joining forces with the Global Sustainability Alliance.',
    content: 'Logistics is responsible for a significant portion of global emissions. Remaq is committed to being part of the solution. By joining the GSA, we have pledged to reduce our operational waste by 40% over the next three years.\n\nThis includes implementing "Smart Packing" protocols and prioritizing carriers with modern, high-efficiency fleets. Our clients can now request "Green Transit Reports" for any shipment managed by our network.',
    image: 'https://images.unsplash.com/photo-1530541930197-ff16ac917b0e?q=80&w=1200&auto=format&fit=crop',
    status: 'Published',
    createdAt: '2024-01-12T15:00:00Z'
  },
  {
    id: 'n5',
    type: 'NEWS',
    title: 'New Service: High-Tech Electronics Specialist Sourcing',
    slug: 'electronics-specialist-sourcing-launch',
    metaTitle: 'Electronics Sourcing Service | Remaq',
    metaDescription: 'Launching a specialized vertical for PCB and consumer electronics manufacturing.',
    excerpt: 'Remaq now offers dedicated sourcing and QC protocols specifically for the electronics industry.',
    content: 'The complexity of electronics manufacturing requires a specialized eye. Today, Remaq launches its Electronics Vertical—a team of engineers and sourcing agents with deep expertise in PCB assembly, component verification, and functional testing.\n\nThis new service includes specialized lab testing for chipset authenticity and multi-stage circuit board audits. If you are building the next big thing in tech, Remaq is your bridge to a reliable factory floor.',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=1200&auto=format&fit=crop',
    status: 'Published',
    createdAt: '2023-12-15T10:00:00Z'
  }
];

export const store = {
  getCurrentUser: () => currentUser,
  setCurrentUser: (user: User | null) => { currentUser = user; },
  
  getShipments: () => shipments,
  getShipmentById: (id: string) => shipments.find(s => s.id === id || s.trackingNumber === id || s.invoiceId === id),
  updateShipment: (updated: Shipment) => {
    shipments = shipments.map(s => s.id === updated.id ? updated : s);
  },
  
  getInvoices: () => invoices,
  getInvoicesByClient: (clientId: string) => invoices.filter(inv => inv.clientId === clientId),
  addInvoice: (inv: Invoice) => { invoices = [inv, ...invoices]; },
  updateInvoice: (updated: Invoice) => {
    invoices = invoices.map(inv => inv.id === updated.id ? updated : inv);
  },
  
  getContents: () => contents,
  getContentBySlug: (slug: string) => contents.find(c => c.slug === slug),
  getPublishedContents: (type: 'BLOG' | 'NEWS') => contents.filter(c => c.type === type && c.status === 'Published'),
  addContent: (post: ContentPost) => { contents = [post, ...contents]; },
  updateContent: (updated: ContentPost) => {
    contents = contents.map(c => c.id === updated.id ? updated : c);
  },
  deleteContent: (id: string) => {
    contents = contents.filter(c => c.id !== id);
  },
  
  getRequests: () => requests,
  getRequestsByClient: (clientId: string) => requests.filter(r => r.clientId === clientId),
  addRequest: (req: SupportRequest) => { requests = [req, ...requests]; },
  updateRequest: (updated: SupportRequest) => {
    requests = requests.map(r => r.id === updated.id ? updated : r);
  },

  getAccountingStats: (startDate?: Date, endDate?: Date) => {
    const filteredInvoices = invoices.filter(inv => {
      if (!inv.issuedDate) return false;
      const d = new Date(inv.issuedDate);
      if (startDate && d < startDate) return false;
      if (endDate && d > endDate) return false;
      return true;
    });

    const filteredRequests = requests.filter(r => {
      const d = new Date(r.createdAt);
      if (startDate && d < startDate) return false;
      if (endDate && d > endDate) return false;
      return true;
    });

    const filteredShipments = shipments.filter(s => {
      const d = new Date(s.lastUpdate);
      if (startDate && d < startDate) return false;
      if (endDate && d > endDate) return false;
      return true;
    });

    const totalRevenue = filteredInvoices.reduce((acc, inv) => acc + inv.totalAmount, 0);
    const totalCosts = filteredInvoices.reduce((acc, inv) => acc + (inv.productCost + inv.shippingCost + inv.inspectionCost), 0);
    const profit = totalRevenue - totalCosts;

    return {
      totalRevenue,
      totalCosts,
      profit,
      totalClients: 1,
      activeShipments: filteredShipments.filter(s => s.status !== ShipmentStatus.DELIVERED).length,
      incomingSignals: filteredRequests.length
    };
  },
  
  login: (email: string): User | null => {
    if (email === 'admin@remaq.com') return MOCK_SUPER_ADMIN;
    if (email === 'ops@remaq.com') return MOCK_ADMIN;
    if (email === 'client@demo.com') return MOCK_CLIENT;
    return null;
  }
};
