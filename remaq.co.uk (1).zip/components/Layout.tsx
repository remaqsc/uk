
import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { store } from '../services/store';

export const Navbar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const user = store.getCurrentUser();

  const handleLogout = () => {
    store.setCurrentUser(null);
    navigate('/');
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 glass border-b border-gray-100`}>
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold tracking-tight text-gray-900">
          REMAQ<span className="font-light text-gray-400 text-sm ml-1">SUPPLY CHAIN</span>
        </Link>
        
        <div className="hidden md:flex items-center space-x-8">
          <Link to="/tracking" className="text-xs font-bold uppercase tracking-widest hover:text-gray-500 transition-colors">Track</Link>
          <Link to="/blog" className="text-xs font-bold uppercase tracking-widest hover:text-gray-500 transition-colors">Blog</Link>
          <Link to="/news" className="text-xs font-bold uppercase tracking-widest hover:text-gray-500 transition-colors">News</Link>
          {user ? (
            <>
              <Link to={user.role === 'ADMIN' ? '/admin' : '/dashboard'} className="text-[10px] font-bold uppercase tracking-widest bg-gray-900 text-white px-6 py-3 rounded-full hover:bg-black transition-colors">
                Dashboard
              </Link>
              <button onClick={handleLogout} className="text-xs font-bold uppercase tracking-widest text-gray-400 hover:text-gray-900 transition-colors">Sign Out</button>
            </>
          ) : (
            <Link to="/auth" className="text-[10px] font-bold uppercase tracking-widest bg-gray-900 text-white px-6 py-3 rounded-full hover:bg-black transition-colors">
              Client Portal
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export const Footer: React.FC = () => (
  <footer className="bg-white border-t border-gray-100 pt-24 pb-12">
    <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:col-span-2 md:grid-cols-4 gap-12">
      <div className="col-span-1 md:col-span-2">
        <h2 className="text-2xl font-bold tracking-tight mb-6">REMAQ</h2>
        <p className="text-gray-500 max-w-sm leading-relaxed">
          Modernizing the bridge between global scaling and reliable manufacturing. 
          Sourcing, quality control, and logistics—managed with precision.
        </p>
      </div>
      <div>
        <h3 className="text-xs font-bold uppercase tracking-widest mb-8 text-gray-900">Services</h3>
        <ul className="space-y-4 text-gray-500 text-sm">
          <li><Link to="/">Product Sourcing</Link></li>
          <li><Link to="/">Quality Inspection</Link></li>
          <li><Link to="/">Global Shipping</Link></li>
          <li><Link to="/">Factory Audits</Link></li>
        </ul>
      </div>
      <div>
        <h3 className="text-xs font-bold uppercase tracking-widest mb-8 text-gray-900">Content</h3>
        <ul className="space-y-4 text-gray-500 text-sm">
          <li><Link to="/blog">Blog & Insights</Link></li>
          <li><Link to="/news">Company News</Link></li>
          <li><Link to="/tracking">Track Shipment</Link></li>
          <li><Link to="/auth">Client Login</Link></li>
        </ul>
      </div>
    </div>
    <div className="max-w-7xl mx-auto px-6 mt-24 pt-12 border-t border-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-400 flex flex-col md:row justify-between items-center space-y-6 md:space-y-0">
      <p>&copy; 2024 Remaq Supply Chain Management Ltd. All rights reserved.</p>
      <div className="flex space-x-8">
        <Link to="/" className="hover:text-gray-900">Privacy Policy</Link>
        <Link to="/" className="hover:text-gray-900">Terms of Service</Link>
      </div>
    </div>
  </footer>
);
